
#This function is for remove NA in the data