# rojas.pkg

## An R package for processing sea turtle hormones data

Users can use this package can use to understand the relationship between hormone concentration during the sea turtle nesting process or preparing for the nesting process.

#Overview:

#functions

#nstallation (including my data)


#Usage para que usar el paquete y como hacerlo

include each funtion in this package